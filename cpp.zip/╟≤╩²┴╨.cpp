﻿// 求数列.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
using namespace std;
int main()
{
    int n;
    while (cin >> n)
    {
        cout << n * (3 * n - 1) / 2 << endl;
    }
    return 0;
}
